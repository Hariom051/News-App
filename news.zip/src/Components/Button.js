import React from "react";

export const Button = ({ country, setcountry, color,setlan }) => {
  const fn = (event) => {
    if (event.target.innerText === "India") {
      setcountry("in");
      setlan("hi");
    } else if (event.target.innerText === "USA") {
      setcountry("us");
      setlan("en");
    } else if (event.target.innerText === "China") {
      setcountry("cn");
      setlan("zh");
    } else if (event.target.innerText === "Australia") {
      setcountry("au");
      setlan("en");
    }
  };
  return (
    <>
      <button onClick={fn} className={color}>
        {country}
      </button>
    </>
  );
};
