export const Error = () => {
  return (
    <>
      <h1 className="text-center" style={{ position: "relative", top: "20vw" }}>
        No Connection <br />
        <button
          className="btn btn-primary"
          onClick={() => {
            window.location.reload(false);
          }}
        >
          Retry
        </button>{" "}
      </h1>
    </>
  );
};
