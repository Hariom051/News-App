import { FetchApi } from "./FetchApi";
import { Button } from "./Button";
import { useState } from "react";
export const Header = () => {
  const [country_code, setcountry] = useState("in");
   const [lan, setlan] = useState("hi");
  return (
    <div className="container">
      <h1 className="alert-primary text-center">News App</h1>
      <div className="container">
        <br />
        <Button
          country_code={country_code}
          setcountry={setcountry}
          country="India"
          color="btn btn-success"
          setlan={setlan}
        />
        &nbsp; &nbsp; &nbsp;
        <Button
        setlan={setlan}
          country_code={country_code}
          setcountry={setcountry}
          country="USA"
          color="btn btn-info"
        />
        &nbsp; &nbsp; &nbsp;
        <Button
        setlan={setlan}
          country_code={country_code}
          setcountry={setcountry}
          country="China"
          color="btn btn-danger"
        />
        &nbsp; &nbsp; &nbsp;
        <Button
        setlan={setlan}
          country_code={country_code}
          setcountry={setcountry}
          country="Australia"
          color="btn btn-warning"
        />
      </div>

      <FetchApi country_code={country_code}  lan={lan} />
    </div>
  );
};
