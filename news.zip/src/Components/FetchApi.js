import { useEffect, useState } from "react";
import axios from "axios";
import { NewsShow } from "./NewsShow";
import { Error } from "./Error";

export const FetchApi = ({ country_code, lan }) => {
  const [load, setload] = useState([]);
  useEffect(() => {
    const fetchapi = () => {
      const url = `https://newsdata.io/api/1/news?apikey=pub_11795a42111042cad863817deaa8cfad09e52&language=${lan}&country=${country_code}`;
      const promise = axios.get(url);
      promise
        .then((data) => {
          setload(data?.data?.results);
    
        })
        .catch((err) => {
          console.log("err is ", err);
        });
    };

    fetchapi();
  }, [country_code]);
  return (
    <>
      {load && load?.length > 0 ? (
        <NewsShow load={load} setload={setload} />
      ) : (
        <Error />
      )}
    </>
  );
};
